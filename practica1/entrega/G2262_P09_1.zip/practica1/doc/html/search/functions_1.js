var searchData=
[
  ['esprimo',['esPrimo',['../ejercicio12a_8c.html#a537b2d92840101891a855c31daa23593',1,'esPrimo(int n):&#160;ejercicio12a.c'],['../ejercicio12b_8c.html#a537b2d92840101891a855c31daa23593',1,'esPrimo(int n):&#160;ejercicio12b.c']]]
];
