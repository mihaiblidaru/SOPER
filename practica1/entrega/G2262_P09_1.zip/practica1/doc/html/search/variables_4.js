var searchData=
[
  ['progreso_5fhermano',['progreso_hermano',['../structThreadArgs.html#adb9645ac234d5278d06c1450af517fad',1,'ThreadArgs']]],
  ['progreso_5fpropio',['progreso_propio',['../structThreadArgs.html#a2a69690c663d2d50d808de734f46a67d',1,'ThreadArgs']]]
];
