var searchData=
[
  ['reservar_5fmatriz_5fcuadrada',['reservar_matriz_cuadrada',['../ejercicio13_8c.html#a783b8c4194493a44ad6eac354b01200e',1,'ejercicio13.c']]]
];
