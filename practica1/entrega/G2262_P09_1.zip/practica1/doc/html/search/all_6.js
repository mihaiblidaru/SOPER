var searchData=
[
  ['num',['num',['../structEstructura.html#a285c7a878885df76016c7cf2ddc4f53f',1,'Estructura']]],
  ['num_5fhijos',['NUM_HIJOS',['../ejercicio12a_8c.html#a9dd395f2e0046c1513c84dfcfb9e54da',1,'ejercicio12a.c']]],
  ['num_5fhilo',['num_hilo',['../structThreadArgs.html#a63a99447b50d466b77759dbe635af785',1,'ThreadArgs']]],
  ['num_5fhilos',['NUM_HILOS',['../ejercicio12b_8c.html#ac07422ff8cd6d473b961d30658414deb',1,'ejercicio12b.c']]],
  ['num_5fproc',['NUM_PROC',['../ejercicio4a_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;ejercicio4a.c'],['../ejercicio4b_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;ejercicio4b.c'],['../ejercicio5a_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;ejercicio5a.c'],['../ejercicio5b_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;ejercicio5b.c']]],
  ['numero',['numero',['../structEstructura.html#aac88eb7b472875436ed5fdf0b84aa1c3',1,'Estructura']]]
];
