var searchData=
[
  ['num',['num',['../structEstructura.html#a285c7a878885df76016c7cf2ddc4f53f',1,'Estructura']]],
  ['num_5fhilo',['num_hilo',['../structThreadArgs.html#a63a99447b50d466b77759dbe635af785',1,'ThreadArgs']]],
  ['numero',['numero',['../structEstructura.html#aac88eb7b472875436ed5fdf0b84aa1c3',1,'Estructura']]]
];
