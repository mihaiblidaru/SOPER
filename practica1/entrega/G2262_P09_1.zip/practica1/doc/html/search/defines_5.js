var searchData=
[
  ['ok',['OK',['../ejercicio9_8c.html#aba51915c87d64af47fb1cc59348961c9',1,'ejercicio9.c']]]
];
