var searchData=
[
  ['cadena',['cadena',['../structEstructura.html#a71ac945c86172d84db00f84c1e451300',1,'Estructura']]],
  ['calcular_5fprimos',['calcular_primos',['../ejercicio12a_8c.html#ae7d8208192e778ce7611972486d1dd97',1,'calcular_primos(int limit):&#160;ejercicio12a.c'],['../ejercicio12b_8c.html#a14d643bc6d1e88405bd2108a17ecda59',1,'calcular_primos(void *e):&#160;ejercicio12b.c']]]
];
