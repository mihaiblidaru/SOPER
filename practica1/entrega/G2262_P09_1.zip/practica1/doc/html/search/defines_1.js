var searchData=
[
  ['false',['FALSE',['../ejercicio12a_8c.html#aa93f0eb578d23995850d61f7d61c55c1',1,'FALSE():&#160;ejercicio12a.c'],['../ejercicio12b_8c.html#aa93f0eb578d23995850d61f7d61c55c1',1,'FALSE():&#160;ejercicio12b.c']]]
];
