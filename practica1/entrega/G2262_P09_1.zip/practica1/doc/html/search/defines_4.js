var searchData=
[
  ['num_5fhijos',['NUM_HIJOS',['../ejercicio12a_8c.html#a9dd395f2e0046c1513c84dfcfb9e54da',1,'ejercicio12a.c']]],
  ['num_5fhilos',['NUM_HILOS',['../ejercicio12b_8c.html#ac07422ff8cd6d473b961d30658414deb',1,'ejercicio12b.c']]],
  ['num_5fproc',['NUM_PROC',['../ejercicio4a_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;ejercicio4a.c'],['../ejercicio4b_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;ejercicio4b.c'],['../ejercicio5a_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;ejercicio5a.c'],['../ejercicio5b_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'NUM_PROC():&#160;ejercicio5b.c']]]
];
