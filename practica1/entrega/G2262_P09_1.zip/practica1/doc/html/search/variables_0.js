var searchData=
[
  ['cadena',['cadena',['../structEstructura.html#a71ac945c86172d84db00f84c1e451300',1,'Estructura']]]
];
